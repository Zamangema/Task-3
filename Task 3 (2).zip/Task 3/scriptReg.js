//let form = document.getElementById('registrationForm').addEventListener('submit', function(event) {
//            // Prevent the form from submitting by default
//            event.preventDefault();
//
//            // Get form input values
//            var firstName = document.getElementById('Fname').value;
//            var surname = document.getElementById('Surname').value;
//            var idNumber = document.getElementById('IDNum').value;
//            var email = document.getElementById('email').value;
//            var jobTitle = document.getElementById('Job').value;
//            var duties = document.getElementById('Duties').value;
//
//            // Basic validation example (you can extend this as needed)
//            if (firstName.trim() === '') {
//                alert('Please enter your first name');
//                return;
//            }
//
//            if (surname.trim() === '') {
//                alert('Please enter your surname');
//                return;
//            }
//
//            if (idNumber.trim() === '' || idNumber.length !== 13 || isNaN(idNumber)) {
//                alert('Please enter a valid 13-digit ID number');
//                return;
//            }
//
//            if (email.trim() === '') {
//                alert('Please enter your email address');
//                return;
//            }
//            if(username !== email )
//            {
//                alert('Username must be your email address');
//                return;  
//            }
//            if(password !== idNumber )
//            {
//                alert('Password must be your ID Number');
//                return;  
//            }
//
//            // If all validations pass, you can submit the form
//            this.submit();
//        });

//console.log(form);
//
let registerForm = document.getElementById('registrationForm');
let submitBtn = document.getElementById('submit');
console.log(submitBtn)
let users = localStorage.getItem('users')
users =  users ? JSON.parse(users) : []

submitBtn.addEventListener('click', (ev) => {
    
    var firstName = document.getElementById('Fname').value;
            var surname = document.getElementById('Surname').value;
            var idNumber = document.getElementById('IDNum').value;
            var email = document.getElementById('email').value;
            var jobTitle = document.getElementById('Job').value;
            var duties = document.getElementById('Duties').value;

            // Basic validation example (you can extend this as needed)
            if (firstName.trim() === '') {
                alert('Please enter your first name');
                return;
            }

            if (surname.trim() === '') {
                alert('Please enter your surname');
                return;
            }

            if (idNumber.trim() === '' || idNumber.length !== 13 || isNaN(idNumber)) {
                alert('Please enter a valid 13-digit ID number');
                return;
            }

            if (email.trim() === '') {
                alert('Please enter your email address');
                return;
            }
        users.push(
            {Name: firstName,
            Surname: surname,
            ID_Number: idNumber,
            Email: email,
            Job_Title: jobTitle,
            Duty: duties}
        )
        localStorage.setItem('users', JSON.stringify(users))
        console.log(firstName, surname)
            
        window.location = './index.html'
                            })

