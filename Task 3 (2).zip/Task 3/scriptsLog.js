let users = JSON.parse(localStorage.getItem('users'))

let submitLoginBtn = document.getElementById('loginsubmit');
submitLoginBtn.addEventListener("click",(Ev) =>{
    
      var username = document.getElementById('username').value; 
      var password = document.getElementById('password').value;
    
    if(!username)
            {
                alert('Username must be your email address');
                return;  
            }
    if(!password)
            {
                alert('Password must be your ID Number');
                return;  
            }
    let foundUser = users.find((user, indx) => user.Email === username)
        if(!foundUser) {
          alert('User is not registered')  
        } 
        else {
            if(foundUser.ID_Number !== password) {
                alert('your password is incorrect')    
            }else {
                    window.location = './tasks.html'        
            }
        }
})
